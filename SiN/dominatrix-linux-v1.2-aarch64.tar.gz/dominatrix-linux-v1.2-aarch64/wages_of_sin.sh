#!/bin/bash

./sin +set game 2015
